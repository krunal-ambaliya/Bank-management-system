package bankmanagementsystem;
import java.io.*;
import java.util.List;
import java.util.Scanner;

public class TransferFunds extends ManageAccount {
    private Scanner scanner;

    public TransferFunds() {
        scanner = new Scanner(System.in);
    }

    @Override
    public void run() {
        boolean exit = false;
        while (!exit) {

            System.out.println("\n=======================================================");
            System.out.println("\t\t\t\tTransfer Funds ");
            System.out.println("=======================================================");
            System.out.println("1. View Transaction History");
            System.out.println("2. To Another Account (External Transfer)");
            System.out.println("9. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    printTransactionHistory();
                    break;
                case 2:
                    externalTransfer();
                    break;
                case 9:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    public void printTransactionHistory() {
        System.out.println("\n--------------- | Transaction History | ---------------");
        System.out.print("\n➥ Enter Account ID to view transaction history: ");
        String accountId = scanner.next();
        boolean found = false;
        List<Account> accounts = FileHandler.readFromFile();
        for (Account account : accounts) {
            if (account.getAccountId().equals(accountId)) {
                System.out.println("Transaction History for Account ID: " + accountId);
                for (String transaction : account.getTransactionHistory()) {
                    if (!transaction.startsWith("Added")) { // Skip balance addition transactions
                        // Split the transaction string to get the details
                        String[] parts = transaction.split(",");
                        if (parts.length >= 3) { // Ensure there are at least 3 parts
                            String type = parts[0];
                            double amount = Double.parseDouble(parts[1]);
                            String fromTo = parts[2];
                            System.out.println("Type: " + type + ", Amount: " + amount + ", From/To: " + fromTo);
                        } else {
                            System.out.println(" " + transaction);
                        }
                    }
                }
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Account not found.");
        }
    }



    private void externalTransfer() {
        System.out.println("\n--------------- | Tranfer funds (external) | ---------------");
        System.out.print("\n➥ Enter Account ID to transfer from: ");
        String fromAccountId = scanner.next();
        System.out.print("➥ Enter Account ID to transfer to: ");
        String toAccountId = scanner.next();
        System.out.print("➥ Enter amount to transfer: ");
        double amount = scanner.nextDouble();
        boolean fromAccountFound = false;
        boolean toAccountFound = false;
        List<Account> accounts = FileHandler.readFromFile();
        for (Account account : accounts) {
            if (account.getAccountId().equals(fromAccountId)) {
                fromAccountFound = true;
                double fromBalance = account.getBalance();
                if (fromBalance >= amount) {
                    for (Account targetAccount : accounts) {
                        if (targetAccount.getAccountId().equals(toAccountId)) {
                            toAccountFound = true;
                            double toBalance = targetAccount.getBalance();
                            account.setBalance(fromBalance - amount);
                            targetAccount.setBalance(toBalance + amount);
                            System.out.println("Transfer successful.");

                            // Update transaction history for source account
                            String fromTransaction = "Transfer to " + "ID " + toAccountId + " " + "amount: " + amount;
                            account.addTransaction(fromTransaction);

                            // Update transaction history for target account
                            String toTransaction = "Received from " + "ID " + fromAccountId + " " + "amount: " + amount;
                            targetAccount.addTransaction(toTransaction);

                            // Write accounts to file after each transfer
                            FileHandler.writeToFile(accounts);

                            break;
                        }
                    }
                } else {
                    System.out.println("Insufficient balance in the source account.");
                }
                break;
            }
        }
        if (!fromAccountFound) {
            System.out.println("Source account not found.");
        }
        if (!toAccountFound) {
            System.out.println("Target account not found.");
        }
    }
}
