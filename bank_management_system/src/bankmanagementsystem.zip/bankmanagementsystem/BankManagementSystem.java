package bankmanagementsystem;

import java.util.Scanner;

public class BankManagementSystem {
    public static Scanner scanner;
    private AccountManagement accountManagement;
    private ManageAccount manageAccount;
    private TransferFunds transferFunds;

    public BankManagementSystem() {
        scanner = new Scanner(System.in);
        accountManagement = new AccountManagement();
        manageAccount = new ManageAccount();
        transferFunds = new TransferFunds();
    }

    public void run() {
        boolean exit = false;
        while (!exit) {
            System.out.println("------------------------------------------------------------");
            System.out.println("\t\t\tBank Management System");
            System.out.println("------------------------------------------------------------");
            System.out.println("1. Account Management");
            System.out.println("2. Manage Account");
            System.out.println("3. Transfer Funds");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    accountManagementMenu();
                    break;
                case 2:
                    manageAccountMenu();
                    break;
                case 3:
                    transferFundsMenu();
                    break;
                case 9:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
        scanner.close();
    }

    private void accountManagementMenu() {
        accountManagement.run();
    }

    private void manageAccountMenu() {
        manageAccount.run();
    }

    private void transferFundsMenu() {
        transferFunds.run();
    }


}
